Kura reflections for SUSY

Source: KuraReflectionsGTNH-V1.4.0.zip (KuramA-777/GTNH-2.9.X-Shader-Edits-and-PBR-Packs,
commit 61984f5). Only files whose base texture exists in SUSY are shipped.

1. Xtones, same block id (xtones:lave), GTNH Ztones index + 1:
   lave_ (12)_s.png -> assets/xtones/textures/blocks/lave/13_s.png
   lave_ (8)_s.png  -> assets/xtones/textures/blocks/lave/9_s.png
   lave_ (8)_n.png  -> assets/xtones/textures/blocks/lave/9_n.png
   The 13 map is uniform (R254 G6 B0 A255), so it fits any Lave 13 face; the 9 maps carry a
   pattern and rely on the +1 index shift being correct for Lave 8 as well.

2. Chisel 1.12.2 blocks whose texture path is identical to GTNH's (exact match, 20 maps):
   laboratory/checkertile, floortile, smalltile, directionleft/right, infocon (n + s)
   planks-{oak,spruce,birch,jungle,acacia,dark-oak}/parquet_s
   tyrian/platetiles (n + s)

Not included, because the base texture path does not exist in SUSY:
   chisel alabaster, cubit, hempcrete, exotic parquet (cherry, fir, greatwood...), hardened clay
   tiles, marble; botania pavements and dark quartz; biomesoplenty shalesmooth; twilightforest
   castle roof; cookingforblockheads kitchen floors; all other ztones sets (agon, azur, bitt,
   glaxx) - those need an index mapping of their own.

Full coverage report: Work/chromapatch/research/reflections-coverage.csv
