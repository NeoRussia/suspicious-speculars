#version 430 compatibility

#define NETHER_SHADER

#define UNDERGROUND_DIM

#include "/dimensions/composite11.vsh"
