#version 430 compatibility

#define WEATHER
#define OVERWORLD_SHADER

#define PLANET_MOON

#include "/dimensions/all_particles.fsh"
